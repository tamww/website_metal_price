# better-sqlite3-with-prebuilds
Better SQLite prebuild & publish action
